// Paste this whole file into the DevTools Console on a LinkedIn post search
// results page (linkedin.com/search/results/content/...). It copies a short
// report of the page structure to your clipboard: tag names, classes, data-*
// attributes and roles only. No post text or names are included.
(() => {
  const URN_RE = /urn:li:(?:activity|ugcPost|share):\d+/;
  const MAX_REPORT_CHARS = 15000;
  const KEPT_ATTRIBUTE = name => name === 'class' || name === 'role' || name.startsWith('data-') || name.startsWith('aria-');

  const selectorCounts = Object.fromEntries(
    [
      'div.feed-shared-update-v2',
      '[data-urn]',
      '[data-id]',
      '[data-chameleon-result-urn]',
      '[data-view-name]',
      '[role="article"]',
      '[role="listitem"]',
      '.update-components-text',
      '.update-components-actor__title',
      '.search-reusable-search-no-results',
    ].map(selector => [selector, document.querySelectorAll(selector).length]),
  );

  const urnAttributes = {};
  const viewNames = {};
  for (const el of document.querySelectorAll('*')) {
    for (const attr of el.attributes) {
      if (URN_RE.test(attr.value)) {
        const key = `${el.tagName.toLowerCase()}[${attr.name}]`;
        urnAttributes[key] = (urnAttributes[key] || 0) + 1;
      }
    }
    const view = el.getAttribute('data-view-name');
    if (view) viewNames[view] = (viewNames[view] || 0) + 1;
  }

  // Like/reaction button labels and pressed state, to tune liked-post detection.
  // Like at least one post on the page before running this.
  const reactionButtons = {};
  for (const button of document.querySelectorAll('button')) {
    const label = button.getAttribute('aria-label') || '';
    if (!/like|react/i.test(label + button.className)) continue;
    const key = `label="${label.slice(0, 60)}" aria-pressed="${button.getAttribute('aria-pressed')}" class="${String(button.className).slice(0, 80)}"`;
    reactionButtons[key] = (reactionButtons[key] || 0) + 1;
  }

  const skeleton = (el, depth = 0) => {
    if (depth > 8) return '  '.repeat(depth) + '…';
    const attrs = [...el.attributes]
      .filter(attr => KEPT_ATTRIBUTE(attr.name))
      .map(attr => `${attr.name}="${attr.value.replace(URN_RE, 'URN').slice(0, 80)}"`)
      .join(' ');
    const hasText = [...el.childNodes].some(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
    const line = `${'  '.repeat(depth)}<${el.tagName.toLowerCase()}${attrs ? ' ' + attrs : ''}>${hasText ? ' #text' : ''}`;
    return [line, ...[...el.children].slice(0, 10).map(child => skeleton(child, depth + 1))].join('\n');
  };

  // Finds one post card: a text element mentioning "hiring", walked up to the
  // level where it sits in a list next to similar siblings.
  const findSampleCard = () => {
    const textEl = [...document.querySelectorAll('span, p, div')].find(
      el => el.children.length <= 2 && /hiring/i.test(el.textContent) && el.textContent.length > 60,
    );
    let node = textEl;
    while (node?.parentElement && node.parentElement !== document.body) {
      const siblings = [...node.parentElement.children].filter(s => s.tagName === node.tagName);
      if (siblings.length >= 3) return node;
      node = node.parentElement;
    }
    return textEl;
  };

  const sample = findSampleCard();
  const report = JSON.stringify(
    {
      url: location.pathname + location.search,
      selectorCounts,
      urnAttributes,
      viewNames,
      reactionButtons,
      sampleCard: sample ? skeleton(sample) : 'No element mentioning "hiring" found',
    },
    null,
    1,
  ).slice(0, MAX_REPORT_CHARS);

  // copy() exists only in the DevTools Console. When the side panel injects
  // this file, the returned report is shown there instead.
  if (typeof copy === 'function') {
    copy(report);
    console.log('Report copied to clipboard. Paste it to whoever is fixing selectors.js.\n\n' + report);
  }
  return report;
})();
