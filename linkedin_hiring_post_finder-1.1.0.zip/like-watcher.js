// Runs on every LinkedIn page. When the user likes a post (feed, search, or
// anywhere else), that post is saved as "already applied" so searches skip it
// and it disappears from the results panel. Unliking removes it again.
(() => {
  if (globalThis.__ljfLikeWatcherLoaded) return;
  globalThis.__ljfLikeWatcherLoaded = true;

  const LIKES = globalThis.LJF_LIKES;

  const send = (key, applied) => {
    try {
      chrome.runtime.sendMessage({ type: 'SET_APPLIED', key, applied }).catch(() => {});
    } catch {
      // Extension was reloaded; this page needs a refresh to report again.
    }
  };

  // Capture phase runs before LinkedIn toggles the button, so the state read
  // here is the state before the click.
  document.addEventListener(
    'click',
    event => {
      const button = event.target.closest?.('button');
      if (!button) return;

      if (LIKES.isReactionMenuChoice(button)) {
        const key = LIKES.postKeyFor(button);
        if (key) send(key, true);
        return;
      }
      if (!LIKES.isReactionTrigger(button)) return;
      const key = LIKES.postKeyFor(button);
      if (key) send(key, !LIKES.isLikedButton(button));
    },
    true,
  );
})();
