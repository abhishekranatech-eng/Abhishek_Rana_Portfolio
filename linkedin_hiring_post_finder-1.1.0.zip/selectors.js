// All LinkedIn DOM selectors live here. LinkedIn changes its markup often:
// when the extension stops finding posts, update these lists first.
// Each entry is a list of fallbacks tried in order.
globalThis.LJF_SELECTORS = {
  post: [
    'div.feed-shared-update-v2[data-urn]',
    '[data-urn^="urn:li:activity:"]',
    '[data-urn^="urn:li:ugcPost:"]',
    '[data-urn^="urn:li:share:"]',
    '[data-id^="urn:li:activity:"]',
  ],
  text: [
    '.update-components-text',
    '.feed-shared-inline-show-more-text',
    '.feed-shared-text',
    '.update-components-update-v2__commentary',
  ],
  seeMore: [
    '.feed-shared-inline-show-more-text__see-more-less-toggle',
    'button[aria-label*="see more" i]',
  ],
  // Fallback: any button whose visible text is just "…more" or "see more".
  seeMoreTextPattern: /^(?:…|\.\.\.)?\s*(?:see\s+)?more$/i,
  authorName: [
    '.update-components-actor__title span[aria-hidden="true"]',
    '.update-components-actor__name span[aria-hidden="true"]',
    '.update-components-actor__title',
  ],
  authorHeadline: [
    '.update-components-actor__description span[aria-hidden="true"]',
    '.update-components-actor__description',
  ],
  authorLink: [
    'a.update-components-actor__meta-link',
    'a.update-components-actor__image',
    '.update-components-actor a[href*="/in/"]',
    '.update-components-actor a[href*="/company/"]',
  ],
  postDate: [
    '.update-components-actor__sub-description span[aria-hidden="true"]',
    '.update-components-actor__sub-description',
  ],
  // The user's own reaction on a post. Liked means "already applied".
  likedButton: [
    'button.react-button__trigger[aria-pressed="true"]',
    'button.react-button--active',
    'button.react-button__trigger--active',
    'button[aria-pressed="true"][aria-label*="like" i]',
    'button[aria-pressed="true"][aria-label*="react" i]',
    'button[aria-label^="Unreact" i]',
  ],
  // The main Like/React button under a post.
  reactionTrigger: [
    'button.react-button__trigger',
    'button[data-view-name*="reaction" i]',
  ],
  // The pop-up with Celebrate, Support, Love, ... choices.
  reactionMenu: [
    '.reactions-menu',
    '[class*="reactions-menu"]',
    '[aria-label*="reactions" i][role="toolbar"]',
  ],
  // Comment "Like" buttons must not count as liking the post.
  comment: [
    'article.comments-comment-entity',
    '.comments-comment-item',
    '[class*="comments-comment"]',
    '[data-id^="urn:li:comment"]',
  ],
  // Newer LinkedIn labels the button "Reaction button state: no reaction"
  // when not liked and "Reaction button state: Like" (or Celebrate, …) when liked.
  likedLabelPattern: /reaction button state:\s*(?!no reaction)\S|^unreact\b/i,
  // Last-resort post cards when no post URN is in the page.
  listItemCard: [
    'main [role="listitem"]',
    'main li',
  ],
  postLink: [
    'a[href*="/feed/update/"]',
    'a[href*="/posts/"]',
  ],
  loadMore: [
    'button.scaffold-finite-scroll__load-button',
  ],
  // Fallback: a button reading "Show more results" / "Load more posts".
  loadMoreTextPattern: /^(?:show|see|load)\s+more\s+(?:results|posts)$/i,
  noResults: [
    '.search-reusable-search-no-results',
    '.artdeco-empty-state',
  ],
};
