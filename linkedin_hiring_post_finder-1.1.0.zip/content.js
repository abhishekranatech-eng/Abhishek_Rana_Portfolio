// Injected into the LinkedIn search tab. Reads the posts the user can see,
// scrolling slowly to load more. Never visits profiles or other pages.
(() => {
  if (globalThis.__ljfContentLoaded) return;
  globalThis.__ljfContentLoaded = true;

  const SEL = globalThis.LJF_SELECTORS;
  const URN_RE = /urn:li:(?:activity|ugcPost|share):\d+/;
  const POST_WAIT_MS = 15000;
  const MIN_CARD_TEXT_LENGTH = 150;
  const MAX_TEXT_LENGTH = 4000;
  // Scrolls in a row that load no new posts before giving up.
  const MAX_IDLE_SCROLLS = 3;
  const MIN_KEY_LETTERS = 40;
  const KEY_LETTERS = 80;
  let cancelled = false;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const scrollDelay = () => sleep(1200 + Math.random() * 800);

  const queryFirst = (root, selectors) => {
    for (const selector of selectors) {
      const el = root.querySelector(selector);
      if (el) return el;
    }
    return null;
  };

  const queryAll = (root, selectors) => {
    for (const selector of selectors) {
      const found = root.querySelectorAll(selector);
      if (found.length) return [...found];
    }
    return [];
  };

  const textOf = el => (el ? el.innerText.trim().replace(/\s+\n/g, '\n') : '');

  const isLoggedOut = () =>
    /^\/(login|authwall|checkpoint|uas\/login|signup)/.test(location.pathname);

  const hasNoResults = () => Boolean(queryFirst(document, SEL.noResults));

  // Returns [{ el, urn, url? }]. Tries, in order: the known selectors, any
  // element carrying a post URN, then large list items in the main column.
  function findPostElements() {
    const bySelector = queryAll(document, SEL.post)
      .map(el => ({ el, urn: (el.getAttribute('data-urn') || el.getAttribute('data-id') || '').match(URN_RE)?.[0] }))
      .filter(post => post.urn);
    if (bySelector.length) return bySelector;
    const byUrn = findPostsByUrnAttribute();
    return byUrn.length ? byUrn : findPostsByListItems();
  }

  // Last resort for layouts with no post URN in the page. The key is the
  // post's own link when there is one, else a hash of the card's opening text.
  function findPostsByListItems() {
    const posts = new Map();
    for (const el of document.querySelectorAll(SEL.listItemCard.join(','))) {
      if (el.parentElement?.closest(SEL.listItemCard.join(','))) continue;
      if (el.innerText.length < MIN_CARD_TEXT_LENGTH) continue;
      const link = queryFirst(el, SEL.postLink);
      const url = link ? link.href.split('?')[0] : null;
      const urn = url ? urnFromLink(url) : textKeyOf(el.innerText) || `text:${hashText(el.innerText.slice(0, 200))}`;
      if (!posts.has(urn)) posts.set(urn, { el, urn, url });
    }
    return [...posts.values()];
  }

  const urnFromLink = url => url.match(URN_RE)?.[0] || `link:${url}`;

  // The same post gets the same key in every search, even with no post id on
  // the page. Uses the start of the longest line (the post body, which stays
  // the same when "…more" cuts it short), letters only, so reaction counts,
  // "2d"/"1w" and Follow/Following can't change it.
  const textKeyOf = text => {
    const longest = String(text).split('\n').reduce((a, b) => (b.length > a.length ? b : a), '');
    const letters = longest.toLowerCase().replace(/[^\p{L}]+/gu, '');
    return letters.length >= MIN_KEY_LETTERS ? `text:${hashText(letters.slice(0, KEY_LETTERS))}` : null;
  };

  const hashText = text => {
    let hash = 5381;
    for (const char of text.replace(/\s+/g, ' ')) hash = ((hash * 33) ^ char.charCodeAt(0)) >>> 0;
    return hash.toString(36);
  };

  function findPostsByUrnAttribute() {
    const posts = new Map();
    for (const el of document.body.querySelectorAll('*')) {
      for (const attr of el.attributes) {
        const urn = attr.value.match(URN_RE)?.[0];
        // Document order puts the outermost element carrying the URN first.
        if (!urn || posts.has(urn)) continue;
        const container = el.tagName === 'A'
          ? el.closest('li, article, [role="listitem"], [role="article"]') || el
          : el;
        posts.set(urn, { el: container, urn });
      }
    }
    return [...posts.values()];
  }

  async function waitForPosts() {
    const deadline = Date.now() + POST_WAIT_MS;
    while (Date.now() < deadline) {
      if (findPostElements().length) return true;
      if (hasNoResults()) return false;
      await sleep(500);
    }
    return false;
  }

  // Opens each post's "…more" so emails and phone numbers below the fold are read.
  // Links are never clicked, so this can't navigate away from the search.
  async function expandSeeMore() {
    const root = document.querySelector('main') || document;
    const byText = [...root.querySelectorAll('button, [role="button"]')].filter(button =>
      SEL.seeMoreTextPattern.test(button.innerText.trim()),
    );
    const buttons = [...new Set([...queryAll(document, SEL.seeMore), ...byText])].filter(
      button => !button.dataset.ljfClicked && button.tagName !== 'A',
    );
    for (const button of buttons) {
      button.dataset.ljfClicked = '1';
      button.click();
    }
    if (buttons.length) await sleep(300);
  }

  // Without a known text selector the whole card text is used; Gemini
  // ignores the extra button labels and author lines.
  function readPost({ el, urn, url }) {
    const text = textOf(queryFirst(el, SEL.text)) || textOf(el);
    if (!text) return null;

    const authorLink = queryFirst(el, SEL.authorLink);
    const rawDate = textOf(queryFirst(el, SEL.postDate));
    return {
      urn,
      url: url || (URN_RE.test(urn) ? `https://www.linkedin.com/feed/update/${urn}/` : null),
      authorName: textOf(queryFirst(el, SEL.authorName)),
      authorHeadline: textOf(queryFirst(el, SEL.authorHeadline)),
      authorUrl: authorLink ? authorLink.href.split('?')[0] : '',
      postDate: rawDate.split('•')[0].trim(),
      text: text.slice(0, MAX_TEXT_LENGTH),
      textKey: textKeyOf(text),
    };
  }

  const isLiked = el => globalThis.LJF_LIKES.isLikedPost(el);

  function reportProgress(scanned, skippedApplied) {
    try {
      chrome.runtime.sendMessage({ type: 'COLLECT_PROGRESS', scanned, skippedApplied }).catch(() => {});
    } catch {
      // Extension was reloaded; nothing to report to.
    }
  }

  // Newer LinkedIn scrolls an inner panel, not the window. Bringing the last
  // post into view scrolls whichever one holds the results.
  function scrollForMore() {
    findPostElements().at(-1)?.el.scrollIntoView({ block: 'end', behavior: 'smooth' });
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    const loadMore =
      queryFirst(document, SEL.loadMore) ||
      [...document.querySelectorAll('button')].find(button =>
        SEL.loadMoreTextPattern.test((button.innerText || '').trim()),
      );
    loadMore?.click();
  }

  // One search's reading state, kept across COLLECT_MORE calls so the
  // background can check posts with Gemini while this keeps scrolling.
  let session = null;

  const newSession = excludeUrns => ({
    excluded: new Set(excludeUrns),
    seen: new Set(),
    skipped: new Set(),
    readCount: 0,
    skippedCount: 0,
    scrolls: 0,
    idleScrolls: 0,
  });

  // Reads posts on screen, skipping liked (already applied) and
  // marked-applied ones. Returns them as soon as at least minNew new posts
  // are found, or when scrolling stops loading anything new.
  async function collectMore({ reset, minNew, maxScrolls, excludeUrns = [] }) {
    if (isLoggedOut()) return { error: 'NOT_LOGGED_IN' };
    if (reset || !session) {
      const ready = await waitForPosts();
      if (!ready) {
        return hasNoResults()
          ? { posts: [], likedUrns: [], scanned: 0, skippedCount: 0, exhausted: true }
          : { error: 'DOM_NOT_FOUND' };
      }
      session = newSession(excludeUrns);
    }

    const posts = [];
    const likedUrns = [];
    let exhausted = false;
    while (!cancelled) {
      await expandSeeMore();
      let foundNew = false;
      for (const found of findPostElements()) {
        if (session.seen.has(found.urn) || session.skipped.has(found.urn)) continue;
        const post = readPost(found);
        if (!post) continue;
        // A post counts as seen or applied if either its id or its text key matches.
        const keys = [post.urn, post.textKey].filter(Boolean);
        if (keys.some(key => session.seen.has(key) || session.skipped.has(key))) continue;
        foundNew = true;
        const excluded = keys.some(key => session.excluded.has(key));
        if (excluded || isLiked(found.el)) {
          keys.forEach(key => session.skipped.add(key));
          session.skippedCount++;
          if (!excluded) likedUrns.push(...keys);
          continue;
        }
        keys.forEach(key => session.seen.add(key));
        session.readCount++;
        posts.push(post);
      }
      reportProgress(session.readCount, session.skippedCount);
      session.idleScrolls = foundNew ? 0 : session.idleScrolls + 1;
      if (posts.length >= minNew) break;
      if (session.scrolls >= maxScrolls || session.idleScrolls >= MAX_IDLE_SCROLLS) {
        exhausted = true;
        break;
      }

      session.scrolls++;
      scrollForMore();
      await scrollDelay();
    }
    return {
      posts,
      likedUrns,
      scanned: session.readCount,
      skippedCount: session.skippedCount,
      exhausted: exhausted || cancelled,
    };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === 'COLLECT_MORE') {
      if (message.reset) cancelled = false;
      collectMore(message)
        .then(sendResponse)
        .catch(err => sendResponse({ error: 'COLLECT_FAILED', detail: err.message }));
      return true;
    }
    if (message.type === 'CANCEL_COLLECT') cancelled = true;
    return false;
  });
})();
