const EMAIL_RE = /[a-z0-9._%+-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}/gi;
const PHONE_RE = /\+?\(?\d[\d\s().-]{7,}\d/g;
const MIN_PHONE_DIGITS = 10;
const MAX_PHONE_DIGITS = 15;

const digitsOf = value => value.replace(/\D/g, '');
const isPhoneLength = value => {
  const count = digitsOf(value).length;
  return count >= MIN_PHONE_DIGITS && count <= MAX_PHONE_DIGITS;
};

const uniqueBy = (items, keyOf) => {
  const seen = new Set();
  return items.filter(item => {
    const key = keyOf(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};

export const extractEmails = text =>
  uniqueBy((text.match(EMAIL_RE) || []).map(e => e.toLowerCase()), e => e);

// Sentence ends and line breaks become commas first, so "…43210. 2020" is not read as one number.
export const extractPhones = text => {
  const separated = text.replace(/\.\s|\n/g, ', ');
  return uniqueBy((separated.match(PHONE_RE) || []).map(p => p.trim()).filter(isPhoneLength), digitsOf);
};

// Gemini output is kept only when it literally appears in the post, so
// contact details can never be invented.
export const verifiedEmails = (candidates, text) => {
  const lowerText = text.toLowerCase();
  return (candidates || [])
    .map(e => String(e).trim().toLowerCase())
    .filter(e => e && lowerText.includes(e));
};

export const verifiedPhones = (candidates, text) => {
  const textDigits = digitsOf(text);
  return (candidates || [])
    .map(p => String(p).trim())
    .filter(p => isPhoneLength(p) && textDigits.includes(digitsOf(p)));
};

export const mergeEmails = (...lists) => uniqueBy(lists.flat(), e => e);
export const mergePhones = (...lists) => uniqueBy(lists.flat(), digitsOf);
