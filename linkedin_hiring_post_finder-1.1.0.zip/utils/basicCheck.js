// Keyword-only stand-in for Gemini, used once every Gemini model's free
// quota is used up. Returns the same shape as a Gemini analysis. Less
// accurate: it can't name the company or job title, and it misses posts
// worded unusually.
import { findSkillsInText } from './skills.js';

const SEEKER = /#?open\s*to\s*work|\b(?:i\s*am|i'm|am)\s+(?:actively\s+)?(?:looking|seeking)\b|\b(?:looking\s+for|seeking)\s+(?:a\s+)?(?:new\s+)?(?:jobs?|opportunit\w*|roles?|positions?)\b/i;
const HIRING = /\bhiring\b|\blooking\s+for\b|\bjob\s+opening|\bopenings?\s+for\b|\bvacanc(?:y|ies)\b|\bopen\s+positions?\b|\b(?:send|share|drop|mail)\s+(?:your\s+)?(?:cv|resume|profile)|\bjoin\s+our\s+team\b|\bimmediate\s+joiners?\b|\bapply\s+(?:now|here|at|via)\b/i;
const INTERNSHIP = /\b(?:intern|interns|internship|trainee|apprentice|apprenticeship)\b/i;
const REGULAR_ROLE = /\b\d+\s*\+?\s*(?:-|to)?\s*\d*\s*(?:years|yrs)\b|\bfull[\s-]?time\b|\bsenior\b|\blead\b|\bsde\s*(?:i|ii|iii|\d)\b/i;
const EXPERIENCE = /\b\d+\s*\+?\s*(?:(?:-|–|to)\s*\d+\s*)?(?:years|yrs)\b/i;
const WORK_MODES = { remote: /\bremote\b|\bwfh\b|work\s+from\s+home/i, hybrid: /\bhybrid\b/i, onsite: /\bon[\s-]?site\b|\bwork\s+from\s+office\b|\bwfo\b/i };
// Words that say nothing about which role it is.
const GENERIC_ROLE_WORDS = new Set(['developer', 'developers', 'engineer', 'engineers', 'dev', 'sde', 'and', 'or', 'the', 'of', 'for', 'a', 'an', 'role', 'job']);
const BASIC_CONFIDENCE = 0.7;

const lettersOnly = text => text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');

// "back-end", "back end" and "backend" all match the role word "backend".
function mentionsRole(text, role) {
  const words = role.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(w => w && !GENERIC_ROLE_WORDS.has(w));
  if (!words.length) return true;
  const squashed = lettersOnly(text);
  return words.some(word => squashed.includes(lettersOnly(word)));
}

function statedWorkMode(text) {
  const stated = Object.keys(WORK_MODES).filter(mode => WORK_MODES[mode].test(text));
  return stated.length === 1 ? stated[0] : null;
}

function analyse(post, query) {
  const text = post.text;
  const workMode = statedWorkMode(text);
  const isJobPost = HIRING.test(text) && !SEEKER.test(text);
  const fitsWorkMode = query.workMode === 'any' || !workMode || workMode === query.workMode;
  return {
    id: post.id,
    isJobPost,
    isInternship: INTERNSHIP.test(text) && !REGULAR_ROLE.test(text),
    matchesQuery: isJobPost && mentionsRole(text, query.role) && fitsWorkMode,
    confidence: BASIC_CONFIDENCE,
    company: null,
    jobTitle: null,
    location: query.location && text.toLowerCase().includes(query.location.toLowerCase()) ? query.location : null,
    workMode: workMode ? workMode[0].toUpperCase() + workMode.slice(1) : null,
    experience: text.match(EXPERIENCE)?.[0] || null,
    matchedSkills: findSkillsInText(text, query.skills),
    // background.js extracts these from the text itself.
    emails: [],
    phones: [],
    applyLink: null,
  };
}

// Same return shape as classifyPosts: a Map of post id -> analysis.
export const classifyPostsBasic = (posts, query) => new Map(posts.map(post => [post.id, analyse(post, query)]));
