// Stops spreadsheet apps from running a cell as a formula, while leaving
// phone numbers like "+91 98..." alone.
const FORMULA_START = /^(?:[=@]|[+-](?!\d))/;

const escapeCell = value => {
  let text = Array.isArray(value) ? value.join('; ') : value == null ? '' : String(value);
  if (FORMULA_START.test(text)) text = `'${text}`;
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

export const toCsv = (rows, columns) =>
  [
    columns.map(column => escapeCell(column.label)).join(','),
    ...rows.map(row => columns.map(column => escapeCell(row[column.key])).join(',')),
  ].join('\r\n');
