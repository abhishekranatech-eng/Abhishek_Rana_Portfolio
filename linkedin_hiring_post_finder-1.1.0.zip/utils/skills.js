export const MAX_SKILLS = 15;

// Spellings that mean the same skill. Matching any one counts as the skill.
const ALIAS_GROUPS = [
  ['node.js', 'nodejs', 'node js', 'node'],
  ['javascript', 'js', 'ecmascript'],
  ['typescript', 'ts'],
  ['react', 'react.js', 'reactjs'],
  ['react native', 'react-native'],
  ['next.js', 'nextjs'],
  ['vue', 'vue.js', 'vuejs'],
  ['angular', 'angularjs', 'angular.js'],
  ['express', 'express.js', 'expressjs'],
  ['nestjs', 'nest.js', 'nest js'],
  ['mongodb', 'mongo', 'mongo db'],
  ['postgresql', 'postgres', 'psql'],
  ['mysql', 'my sql'],
  ['aws', 'amazon web services'],
  ['gcp', 'google cloud', 'google cloud platform'],
  ['azure', 'microsoft azure'],
  ['kubernetes', 'k8s'],
  ['golang', 'go'],
  ['c#', 'csharp', 'c sharp'],
  ['.net', 'dotnet', 'asp.net'],
  ['c++', 'cpp'],
  ['graphql', 'graph ql'],
  ['ci/cd', 'cicd', 'ci cd'],
];

export const normalizeSkill = raw => String(raw).trim().replace(/\s+/g, ' ');
export const skillKey = skill => normalizeSkill(skill).toLowerCase();

const escapeRegex = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// "node.js" -> also "nodejs" and "node js". Leading dots (".net") are kept.
const autoVariants = key => [
  key,
  key.replace(/(\w)\.(\w)/g, '$1$2'),
  key.replace(/(\w)\.(\w)/g, '$1 $2'),
];

export function skillVariants(skill) {
  const variants = new Set(autoVariants(skillKey(skill)));
  for (const group of ALIAS_GROUPS) {
    if (group.some(alias => variants.has(alias))) group.forEach(alias => variants.add(alias));
  }
  return [...variants].filter(Boolean);
}

// Whole-word match, so "Go" does not match "good" and "C" does not match "C++".
export function buildSkillRegex(skill) {
  const alternatives = skillVariants(skill)
    .sort((a, b) => b.length - a.length)
    .map(variant => escapeRegex(variant).replace(/ /g, '[\\s-]+'));
  return new RegExp(`(?<![a-z0-9+#.])(?:${alternatives.join('|')})(?![a-z0-9+#])`, 'i');
}

export const findSkillsInText = (text, skills) =>
  skills.filter(skill => buildSkillRegex(skill).test(text));
