// Contact details from every search, one entry per job post:
// { postKey: { company, jobTitle, authorName, emails, phones, postUrl, foundAt } }.
export const SAVED_CONTACTS_KEY = 'savedContacts';

export async function getSavedContacts() {
  const stored = await chrome.storage.local.get(SAVED_CONTACTS_KEY);
  return stored[SAVED_CONTACTS_KEY] || {};
}

export async function saveContactsFrom(jobs) {
  const withContacts = jobs.filter(job => job.emails.length || job.phones.length);
  if (!withContacts.length) return;

  const saved = await getSavedContacts();
  const now = Date.now();
  for (const job of withContacts) {
    const key = job.urn || job.postUrl;
    saved[key] = {
      company: job.company,
      jobTitle: job.jobTitle,
      authorName: job.authorName,
      emails: job.emails,
      phones: job.phones,
      postUrl: job.postUrl,
      foundAt: saved[key]?.foundAt ?? now,
    };
  }
  await chrome.storage.local.set({ [SAVED_CONTACTS_KEY]: saved });
}

export const clearSavedContacts = () => chrome.storage.local.remove(SAVED_CONTACTS_KEY);
