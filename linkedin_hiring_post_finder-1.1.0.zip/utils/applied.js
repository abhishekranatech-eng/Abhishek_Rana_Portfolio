// Posts the user already applied to (liked on LinkedIn, or marked in the
// panel), stored as { urn: markedAt }. These never show up in results again.
export const APPLIED_STORAGE_KEY = 'appliedPosts';
const MAX_ENTRIES = 5000;
const URN_RE = /urn:li:(?:activity|ugcPost|share):\d+/;

export const urnFromUrl = url => String(url || '').match(URN_RE)?.[0] || null;

export async function getAppliedPosts() {
  const stored = await chrome.storage.local.get(APPLIED_STORAGE_KEY);
  return stored[APPLIED_STORAGE_KEY] || {};
}

export async function markApplied(urns) {
  const applied = await getAppliedPosts();
  const now = Date.now();
  for (const urn of urns) applied[urn] ??= now;

  const entries = Object.entries(applied);
  const kept = entries.length > MAX_ENTRIES
    ? Object.fromEntries(entries.sort((a, b) => b[1] - a[1]).slice(0, MAX_ENTRIES))
    : applied;
  await chrome.storage.local.set({ [APPLIED_STORAGE_KEY]: kept });
}

export async function unmarkApplied(urn) {
  const applied = await getAppliedPosts();
  if (!(urn in applied)) return;
  delete applied[urn];
  await chrome.storage.local.set({ [APPLIED_STORAGE_KEY]: applied });
}

export const clearAppliedPosts = () => chrome.storage.local.remove(APPLIED_STORAGE_KEY);
