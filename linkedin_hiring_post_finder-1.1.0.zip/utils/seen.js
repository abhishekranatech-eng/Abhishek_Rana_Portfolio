// Everything already shown in an earlier search, stored as { key: shownAt }.
// Keys are the ones background.js dedupes on: "post:<urn>", "job:<company>|<title>",
// "email:<address>" and "phone:<digits>", so a repost of the same job by
// another recruiter, with the same contact details, is skipped too.
export const SEEN_STORAGE_KEY = 'seenKeys';
const MAX_ENTRIES = 20000;
const POST_PREFIX = 'post:';

export async function getSeenKeys() {
  const stored = await chrome.storage.local.get(SEEN_STORAGE_KEY);
  return stored[SEEN_STORAGE_KEY] || {};
}

export async function addSeenKeys(keys) {
  if (!keys.length) return;
  const seen = await getSeenKeys();
  const now = Date.now();
  for (const key of keys) seen[key] ??= now;

  const entries = Object.entries(seen);
  const kept = entries.length > MAX_ENTRIES
    ? Object.fromEntries(entries.sort((a, b) => b[1] - a[1]).slice(0, MAX_ENTRIES))
    : seen;
  await chrome.storage.local.set({ [SEEN_STORAGE_KEY]: kept });
}

// Post ids among the seen keys, for the content script to skip before Gemini.
export const seenPostIds = seen =>
  Object.keys(seen).filter(key => key.startsWith(POST_PREFIX)).map(key => key.slice(POST_PREFIX.length));

export const countSeenPosts = seen => seenPostIds(seen).length;

export const clearSeenKeys = () => chrome.storage.local.remove(SEEN_STORAGE_KEY);
