import { getAppliedPosts, markApplied, unmarkApplied } from './utils/applied.js';
import { classifyPostsBasic } from './utils/basicCheck.js';
import { classifyPosts, listUsableModels } from './utils/gemini.js';
import { getSavedContacts, saveContactsFrom } from './utils/savedContacts.js';
import { addSeenKeys, getSeenKeys, seenPostIds } from './utils/seen.js';
import { findSkillsInText, skillKey } from './utils/skills.js';
import {
  extractEmails,
  extractPhones,
  mergeEmails,
  mergePhones,
  verifiedEmails,
  verifiedPhones,
} from './utils/contacts.js';

const DEFAULT_MODEL = 'gemini-flash-latest';
const SEARCH_URL = 'https://www.linkedin.com/search/results/content/';
const SEARCH_SKILL_COUNT = 2;
const MAX_SCROLLS = 25;
// Each search starts from the next phrase, so LinkedIn returns a different
// set of posts instead of the same newest ones every time.
const SEARCH_PHRASES = ['hiring', 'we are hiring', 'looking for', 'job opening', 'urgent hiring', 'immediate joiner'];
// Phrases tried in one search before giving up on reaching Max results.
const MAX_PHRASES_PER_SEARCH = 3;
// Bigger batches mean fewer requests against the small free daily quota.
const BATCH_SIZE = 20;
// Free-tier rate limits are low; two calls at once is the safe maximum.
const MAX_PARALLEL_CALLS = 2;
const MIN_CONFIDENCE = 0.6;
// Backs up Gemini's isInternship flag when the job title says it plainly.
const INTERNSHIP_TITLE = /\b(?:intern|interns|internship|trainee|apprentice|apprenticeship)\b/i;
const TAB_LOAD_TIMEOUT_MS = 30000;
// Chrome resets the service worker idle timer on any extension API call.
// Firefox only resets it on incoming events, so the panel also sends
// KEEP_ALIVE messages while a search runs.
const KEEP_ALIVE_MS = 20000;

const COLLECT_ERRORS = {
  NOT_LOGGED_IN: 'You are not logged into LinkedIn. Log in, then search again.',
  DOM_NOT_FOUND: 'Could not find posts on the LinkedIn page. LinkedIn may have changed its layout. Run tools/diagnose-linkedin.js on the search page (see README) and update selectors.js.',
  COLLECT_FAILED: 'Reading posts from LinkedIn failed.',
};

class SearchError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

// Chrome opens its side panel from the toolbar button; Firefox has no side
// panel, so the button toggles Firefox's sidebar instead.
if (chrome.sidePanel) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
} else if (globalThis.browser?.sidebarAction) {
  chrome.action.onClicked.addListener(() => browser.sidebarAction.toggle());
}

let run = null;
let state = {};

// A fresh worker that finds a "running" search means the old worker died mid-search.
chrome.storage.local.get('searchState').then(({ searchState }) => {
  if (run || searchState?.status !== 'running') return;
  chrome.storage.local.set({
    searchState: {
      ...searchState,
      status: 'error',
      error: { code: 'INTERRUPTED', message: 'The search was interrupted. Please search again.' },
    },
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'START_SEARCH':
      if (run) {
        sendResponse({ ok: false, error: 'A search is already running.' });
        return false;
      }
      startSearch(message.query);
      sendResponse({ ok: true });
      return false;
    case 'CANCEL_SEARCH':
      cancelSearch();
      sendResponse({ ok: true });
      return false;
    case 'KEEP_ALIVE':
      return false;
    case 'SET_APPLIED':
      if (typeof message.key === 'string') setApplied(message.key, message.applied);
      return false;
    case 'COLLECT_PROGRESS':
      if (run && sender.tab?.id === run.tabId) {
        setState({
          scanned: run.scannedBefore + message.scanned,
          skippedApplied: run.skippedBefore + (message.skippedApplied || 0),
        });
      }
      return false;
    default:
      return false;
  }
});

// Likes from the page arrive one click at a time; queue them so two quick
// clicks can't overwrite each other's read-modify-write of the stored list.
let appliedQueue = Promise.resolve();

function setApplied(key, applied) {
  appliedQueue = appliedQueue
    .then(() => (applied ? markApplied([key]) : unmarkApplied(key)))
    .catch(() => {});
}

async function setState(patch) {
  state = { ...state, ...patch };
  await chrome.storage.local.set({ searchState: state });
}

async function startSearch(query) {
  run = { cancelled: false, tabId: null, scannedBefore: 0, skippedBefore: 0 };
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), KEEP_ALIVE_MS);
  try {
    state = {};
    await setState({
      status: 'running',
      step: 'Opening LinkedIn search…',
      scanned: 0,
      skippedApplied: 0,
      prefiltered: 0,
      analyzed: 0,
      matched: 0,
      basicChecked: 0,
      model: null,
      error: null,
      startedAt: Date.now(),
      finishedAt: null,
    });
    await chrome.storage.local.set({ results: [] });

    const results = await runSearch(query);
    await chrome.storage.local.set({ results });
    await setState({
      status: run.cancelled ? 'cancelled' : 'done',
      step: '',
      matched: results.length,
      finishedAt: Date.now(),
    });
  } catch (err) {
    // Keeps what was found before the error, e.g. a lost LinkedIn tab.
    const partial = sortResults(run.results || []).slice(0, run.maxResults);
    if (partial.length) await chrome.storage.local.set({ results: partial });
    await setState({
      status: 'error',
      matched: partial.length,
      step: '',
      error: { code: err.code || 'UNKNOWN', message: err.message },
      finishedAt: Date.now(),
    });
  } finally {
    clearInterval(keepAlive);
    run = null;
  }
}

function cancelSearch() {
  if (!run) return;
  run.cancelled = true;
  setState({ step: 'Cancelling…' });
  if (run.tabId) chrome.tabs.sendMessage(run.tabId, { type: 'CANCEL_COLLECT' }).catch(() => {});
}

async function runSearch(query) {
  const { settings = {} } = await chrome.storage.local.get('settings');
  if (!settings.apiKey) throw new SearchError('NO_API_KEY', 'Add your Gemini API key in Settings first.');
  const configuredModel = settings.model?.trim() || DEFAULT_MODEL;
  let model = configuredModel;

  // Each model has its own free quota. When one runs out (or doesn't exist),
  // the search moves to the next Flash model, and to basic keyword matching
  // once none has quota left. Parallel batches share one switch.
  const unusable = new Set(await getExhaustedModels());
  let usableModels = null;
  let basicOnly = false;
  let modelSwitch = null;
  const switchModel = async ({ saveAsDefault }) => {
    usableModels ??= await listUsableModels(settings.apiKey);
    const next = usableModels.find(name => !unusable.has(name));
    if (!next) {
      basicOnly = true;
      await setState({ model: null, step: 'Gemini limit reached. Checking the rest with basic matching…' });
      return;
    }
    model = next;
    await setState({ model });
    // A retired model is replaced for good; a used-up quota only for today.
    if (saveAsDefault) await chrome.storage.local.set({ settings: { ...settings, model } });
  };
  if (unusable.has(model)) await switchModel({ saveAsDefault: false });

  const classify = async batch => {
    for (;;) {
      if (basicOnly) return { analyses: classifyPostsBasic(batch, query), basic: true };
      const usedModel = model;
      try {
        const analyses = await classifyPosts({ apiKey: settings.apiKey, model: usedModel, query, posts: batch });
        return { analyses, basic: false };
      } catch (error) {
        if (error.code !== 'MODEL_NOT_FOUND' && error.code !== 'RATE_LIMITED') throw error;
        if (error.daily) await rememberExhausted(usedModel);
        unusable.add(usedModel);
        if (model === usedModel && !basicOnly) {
          const saveAsDefault = error.code === 'MODEL_NOT_FOUND' && usedModel === configuredModel;
          await (modelSwitch ??= switchModel({ saveAsDefault }).finally(() => {
            modelSwitch = null;
          }));
        }
      }
    }
  };

  // Seen keys are always recorded, but only used to skip when "Hide posts
  // from earlier searches" is ticked.
  await seedSeenFromContacts();
  const seen = query.hideSeen === false ? {} : await getSeenKeys();
  const results = [];
  const seenKeys = new Set(Object.keys(seen));
  let seenQueue = Promise.resolve();
  const inFlight = new Set();
  let failure = null;
  let order = 0;
  let prefiltered = 0;
  let analyzed = 0;

  let basicChecked = 0;
  run.results = results;
  run.maxResults = query.maxResults;

  const accept = async (batch, { analyses, basic }) => {
    const accepted = [];
    for (const post of batch) {
      const record = toRecord(post, analyses.get(post.id), query);
      if (!record) continue;
      record.checkedBy = basic ? 'basic' : 'gemini';
      const keys = dedupeKeys(record);
      if (keys.some(key => seenKeys.has(key))) continue;
      keys.forEach(key => seenKeys.add(key));
      accepted.push(record);
    }
    results.push(...accepted);
    // Parallel batches finish in any order; queued so neither overwrites the other.
    const newKeys = accepted.flatMap(dedupeKeys);
    seenQueue = seenQueue.then(() => addSeenKeys(newKeys)).catch(() => {});
    analyzed += batch.length;
    if (basic) basicChecked += batch.length;
    // Saved per batch so contacts survive a later rate-limit error or cancel.
    await saveContactsFrom(accepted);
    await setState({ analyzed, basicChecked, matched: Math.min(results.length, query.maxResults) });
  };

  const startBatch = batch => {
    const call = classify(batch)
      .then(result => accept(batch, result))
      .catch(error => {
        failure ??= error;
      })
      .finally(() => inFlight.delete(call));
    inFlight.add(call);
  };

  const enough = () => results.length >= query.maxResults || run.cancelled || failure;

  const applied = await getAppliedPosts();
  const { searchRound = 0 } = await chrome.storage.local.get('searchRound');
  // Posts read under an earlier phrase in this search, so they aren't re-checked.
  const readThisSearch = new Set();
  let pending = [];
  let scannedBefore = 0;
  let skippedBefore = 0;
  let phrasesUsed = 0;

  while (phrasesUsed < MAX_PHRASES_PER_SEARCH && !enough()) {
    const round = searchRound + phrasesUsed;
    phrasesUsed++;
    const phrase = SEARCH_PHRASES[round % SEARCH_PHRASES.length];
    await setState({ step: `Searching LinkedIn for "${phrase}" posts (${phrasesUsed} of ${MAX_PHRASES_PER_SEARCH})…` });
    run.tabId = await openSearchTab(buildSearchUrl(query, round));
    if (run.cancelled) break;

    let exhausted = false;
    let first = true;
    let scanned = 0;
    let skipped = 0;
    while (!exhausted && !enough()) {
      const chunk = await collectMore(run.tabId, {
        reset: first,
        minNew: BATCH_SIZE,
        excludeUrns: first ? [...Object.keys(applied), ...seenPostIds(seen), ...readThisSearch] : [],
      });
      first = false;
      exhausted = chunk.exhausted;
      ({ scanned } = chunk);
      skipped = chunk.skippedCount;
      chunk.posts.forEach(post => [post.urn, post.textKey].filter(Boolean).forEach(key => readThisSearch.add(key)));
      // Remember liked posts so they stay hidden even if a later search can't see the like.
      if (chunk.likedUrns.length) {
        appliedQueue = appliedQueue.then(() => markApplied(chunk.likedUrns)).catch(() => {});
      }

      const candidates = chunk.posts
        .map(post => ({ ...post, id: String(order), order: order++ }))
        .filter(post => findSkillsInText(post.text, query.skills).length > 0);
      prefiltered += candidates.length;
      pending.push(...candidates);
      await setState({
        scanned: scannedBefore + scanned,
        skippedApplied: skippedBefore + skipped,
        prefiltered,
      });

      // A part-full batch waits for more posts, unless the page has run out.
      while (pending.length >= BATCH_SIZE || (exhausted && pending.length)) {
        if (enough()) break;
        startBatch(pending.splice(0, BATCH_SIZE));
        if (inFlight.size >= MAX_PARALLEL_CALLS) await Promise.race(inFlight);
      }
    }
    scannedBefore += scanned;
    skippedBefore += skipped;
    run.scannedBefore = scannedBefore;
    run.skippedBefore = skippedBefore;
    // Lets in-flight batches finish so enough() sees their results before
    // deciding whether the next phrase is needed.
    await Promise.all(inFlight);
  }
  await chrome.storage.local.set({ searchRound: searchRound + phrasesUsed });
  await Promise.all(inFlight);
  await appliedQueue;
  await seenQueue;
  if (failure) throw failure;

  return sortResults(results).slice(0, query.maxResults);
}

// Round n uses phrase n and, when there are more skills than fit, the next
// pair of skills, so repeated searches cover different posts.
function buildSearchUrl(query, round) {
  const phrase = SEARCH_PHRASES[round % SEARCH_PHRASES.length];
  const offset = query.skills.length > SEARCH_SKILL_COUNT ? round % query.skills.length : 0;
  const skills = [...query.skills.slice(offset), ...query.skills.slice(0, offset)].slice(0, SEARCH_SKILL_COUNT);
  const keywords = [phrase, query.role, ...skills, query.location]
    .filter(Boolean)
    .join(' ');
  const url = new URL(SEARCH_URL);
  url.searchParams.set('keywords', keywords);
  url.searchParams.set('sortBy', '"date_posted"');
  if (query.postedWithin !== 'any') url.searchParams.set('datePosted', `"${query.postedWithin}"`);
  url.searchParams.set('origin', 'FACETED_SEARCH');
  return url.toString();
}

// Reuses the tab from the previous search so repeated searches don't pile up tabs.
async function openSearchTab(url) {
  const { searchTabId } = await chrome.storage.session.get('searchTabId');
  const tab = searchTabId ? await chrome.tabs.get(searchTabId).catch(() => null) : null;
  const tabId = tab
    ? await waitForTabLoad(tab.id, () => chrome.tabs.update(tab.id, { url, active: true }))
    : await waitForTabLoad(null, () => chrome.tabs.create({ url, active: true }));
  await chrome.storage.session.set({ searchTabId: tabId });
  return tabId;
}

// Attaches the listener before navigating so the "complete" event can't be missed.
function waitForTabLoad(knownTabId, navigate) {
  return new Promise((resolve, reject) => {
    let tabId = knownTabId;
    const timer = setTimeout(() => finish(new SearchError('TAB_TIMEOUT', 'LinkedIn took too long to load. Try again.')), TAB_LOAD_TIMEOUT_MS);
    const onUpdated = (id, info, tab) => {
      if (id === tabId && info.status === 'complete' && tab.url?.startsWith('https://www.linkedin.com/')) finish();
    };
    const onRemoved = id => {
      if (id === tabId) finish(new SearchError('TAB_CLOSED', 'The LinkedIn tab was closed during the search.'));
    };
    function finish(error) {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      if (error) reject(error);
      else resolve(tabId);
    }
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
    Promise.resolve(navigate())
      .then(tab => {
        tabId = tab.id;
      })
      .catch(err => finish(new SearchError('TAB_ERROR', `Could not open LinkedIn: ${err.message}`)));
  });
}

// The content script is injected on the first chunk; later chunks continue
// the same scroll session.
async function collectMore(tabId, { reset, minNew, excludeUrns }) {
  let response;
  try {
    if (reset) {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['selectors.js', 'likes.js', 'content.js'] });
    }
    response = await chrome.tabs.sendMessage(tabId, {
      type: 'COLLECT_MORE',
      reset,
      minNew,
      maxScrolls: MAX_SCROLLS,
      excludeUrns,
    });
  } catch (err) {
    throw new SearchError('COLLECT_FAILED', `Lost connection to the LinkedIn tab. Keep it open during the search. (${err.message})`);
  }
  if (response?.error) {
    throw new SearchError(response.error, COLLECT_ERRORS[response.error] || response.detail || 'Reading posts failed.');
  }
  return {
    posts: response?.posts || [],
    likedUrns: response?.likedUrns || [],
    scanned: response?.scanned || 0,
    skippedCount: response?.skippedCount || 0,
    exhausted: response?.exhausted ?? true,
  };
}

function toRecord(post, analysis, query) {
  if (!analysis?.isJobPost || !analysis.matchesQuery) return null;
  if (!(analysis.confidence >= MIN_CONFIDENCE)) return null;
  if (query.hideInternships !== false && (analysis.isInternship || INTERNSHIP_TITLE.test(analysis.jobTitle || ''))) {
    return null;
  }

  const matchedSkills = toUserSkills(analysis.matchedSkills, query.skills);
  const skillsOk = query.matchMode === 'all'
    ? matchedSkills.length === query.skills.length
    : matchedSkills.length > 0;
  if (!skillsOk) return null;

  const applyLink = cleanText(analysis.applyLink);
  return {
    company: cleanText(analysis.company),
    jobTitle: cleanText(analysis.jobTitle),
    matchedSkills,
    location: cleanText(analysis.location),
    workMode: cleanText(analysis.workMode),
    experience: cleanText(analysis.experience),
    emails: mergeEmails(extractEmails(post.text), verifiedEmails(analysis.emails, post.text)),
    phones: mergePhones(extractPhones(post.text), verifiedPhones(analysis.phones, post.text)),
    applyLink: applyLink && /^https?:\/\//i.test(applyLink) && post.text.includes(applyLink) ? applyLink : null,
    authorName: post.authorName,
    authorHeadline: post.authorHeadline,
    authorUrl: post.authorUrl,
    postDate: post.postDate,
    postUrl: post.url,
    urn: post.urn,
    textKey: post.textKey || null,
    confidence: analysis.confidence,
    order: post.order,
  };
}

// Maps Gemini's skill names back to the user's exact spelling, dropping anything not in the user's list.
function toUserSkills(geminiSkills, userSkills) {
  const byKey = new Map(userSkills.map(skill => [skillKey(skill), skill]));
  const matched = (geminiSkills || []).map(skill => byKey.get(skillKey(skill))).filter(Boolean);
  return [...new Set(matched)];
}

const cleanText = value => (typeof value === 'string' && value.trim() ? value.trim() : null);

// Google resets free quotas at midnight Pacific time.
const quotaDay = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });

// Models whose daily quota ran out today, so the next search skips straight past them.
async function getExhaustedModels() {
  const { exhaustedModels } = await chrome.storage.local.get('exhaustedModels');
  return exhaustedModels?.day === quotaDay() ? exhaustedModels.models : [];
}

async function rememberExhausted(model) {
  const models = await getExhaustedModels();
  if (models.includes(model)) return;
  await chrome.storage.local.set({ exhaustedModels: { day: quotaDay(), models: [...models, model] } });
}

// Results shown before the seen list existed are still in All contacts.
// Copies them in once, so "Clear seen list" isn't undone on the next search.
async function seedSeenFromContacts() {
  const { seenSeededFromContacts } = await chrome.storage.local.get('seenSeededFromContacts');
  if (seenSeededFromContacts) return;
  const contacts = Object.entries(await getSavedContacts());
  const keys = contacts.flatMap(([key, contact]) =>
    dedupeKeys({ ...contact, urn: key, emails: contact.emails || [], phones: contact.phones || [] }),
  );
  await addSeenKeys(keys);
  await chrome.storage.local.set({ seenSeededFromContacts: true });
}

function dedupeKeys(record) {
  const keys = [`post:${record.urn}`];
  if (record.textKey) keys.push(`post:${record.textKey}`);
  if (record.company && record.jobTitle) {
    keys.push(`job:${record.company.toLowerCase()}|${record.jobTitle.toLowerCase()}`);
  }
  for (const email of record.emails) keys.push(`email:${email.toLowerCase()}`);
  for (const phone of record.phones) keys.push(`phone:${phone.replace(/\D/g, '').slice(-10)}`);
  return keys;
}

// Most matched skills first; LinkedIn already returned posts newest first.
const sortResults = results =>
  [...results].sort((a, b) => b.matchedSkills.length - a.matchedSkills.length || a.order - b.order);
