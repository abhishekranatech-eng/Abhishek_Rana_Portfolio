import {
  APPLIED_STORAGE_KEY,
  clearAppliedPosts,
  getAppliedPosts,
  urnFromUrl,
} from './utils/applied.js';
import { clearSeenKeys, countSeenPosts, getSeenKeys, SEEN_STORAGE_KEY } from './utils/seen.js';
import { clearSavedContacts, getSavedContacts, SAVED_CONTACTS_KEY } from './utils/savedContacts.js';
import { MAX_SKILLS, normalizeSkill, skillKey } from './utils/skills.js';
import { toCsv } from './utils/csv.js';

const DEFAULT_MODEL = 'gemini-flash-latest';
const MAX_RESULTS_LIMIT = 50;
const DEFAULT_FORM = {
  role: '',
  skills: [],
  matchMode: 'any',
  location: '',
  workMode: 'any',
  postedWithin: 'past-week',
  maxResults: 20,
  hideInternships: true,
  hideSeen: true,
};
const CSV_COLUMNS = [
  { key: 'company', label: 'Company' },
  { key: 'jobTitle', label: 'Job title' },
  { key: 'matchedSkills', label: 'Matched skills' },
  { key: 'location', label: 'Location' },
  { key: 'workMode', label: 'Work mode' },
  { key: 'experience', label: 'Experience' },
  { key: 'emails', label: 'Emails' },
  { key: 'phones', label: 'Phones' },
  { key: 'applyLink', label: 'Apply link' },
  { key: 'authorName', label: 'Posted by' },
  { key: 'authorHeadline', label: 'Poster headline' },
  { key: 'postDate', label: 'Posted' },
  { key: 'postUrl', label: 'Post URL' },
];
const MISSING = '-';

const $ = id => document.getElementById(id);
let form = { ...DEFAULT_FORM };
let results = [];

init();

async function init() {
  const stored = await chrome.storage.local.get(['form', 'settings', 'searchState', 'results']);
  form = { ...DEFAULT_FORM, ...stored.form };
  const settings = stored.settings || {};
  $('api-key').value = settings.apiKey || '';
  $('model').value = settings.model || DEFAULT_MODEL;
  $('settings-panel').open = !settings.apiKey;

  fillForm();
  renderSkills();
  renderState(stored.searchState);
  renderResults(stored.results || []);
  renderAppliedInfo(await getAppliedPosts());
  renderSeenInfo(await getSeenKeys());
  renderSavedContacts(await getSavedContacts());
  bindEvents();
  renderAccess();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.searchState) renderState(changes.searchState.newValue);
    // The background switches to a working model when the saved one is retired.
    if (changes.settings && document.activeElement !== $('model')) {
      $('model').value = changes.settings.newValue?.model || DEFAULT_MODEL;
    }
    if (changes.results) renderResults(changes.results.newValue || []);
    if (changes[APPLIED_STORAGE_KEY]) renderAppliedInfo(changes[APPLIED_STORAGE_KEY].newValue || {});
    if (changes[SEEN_STORAGE_KEY]) renderSeenInfo(changes[SEEN_STORAGE_KEY].newValue || {});
    if (changes[SAVED_CONTACTS_KEY]) renderSavedContacts(changes[SAVED_CONTACTS_KEY].newValue || {});
  });
}

function bindEvents() {
  $('grant-access').addEventListener('click', grantAccess);
  $('save-settings').addEventListener('click', saveSettings);
  $('clear-applied').addEventListener('click', event => confirmTwice(event.currentTarget, clearAppliedPosts));
  $('clear-seen').addEventListener('click', event => confirmTwice(event.currentTarget, clearSeenKeys));
  $('clear-contacts').addEventListener('click', event => confirmTwice(event.currentTarget, clearSavedContacts));
  $('copy-emails').addEventListener('click', () => copyLines(allEmails(), 'email'));
  $('copy-phones').addEventListener('click', () => copyLines(allPhones(), 'phone number'));
  $('copy-contacts').addEventListener('click', () => copyLines(contactLines(), 'contact'));
  $('diagnose-btn').addEventListener('click', runDiagnosis);
  $('copy-report').addEventListener('click', copyReport);
  $('add-skill').addEventListener('click', addSkillsFromInput);
  $('skill-input').addEventListener('keydown', event => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    addSkillsFromInput();
  });
  $('search-form').addEventListener('input', onFormEdit);
  $('search-form').addEventListener('change', onFormEdit);
  $('search-form').addEventListener('submit', onSearch);
  $('cancel-btn').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'CANCEL_SEARCH' }));
  $('export-csv').addEventListener('click', exportCsv);
  $('copy-json').addEventListener('click', copyJson);
}

function fillForm() {
  $('role').value = form.role;
  $('location').value = form.location;
  $('work-mode').value = form.workMode;
  $('posted-within').value = form.postedWithin;
  $('max-results').value = form.maxResults;
  $('hide-internships').checked = form.hideInternships;
  $('hide-seen').checked = form.hideSeen;
  document.querySelector(`input[name="matchMode"][value="${form.matchMode}"]`).checked = true;
}

function readForm() {
  form.role = $('role').value.trim();
  form.location = $('location').value.trim();
  form.workMode = $('work-mode').value;
  form.postedWithin = $('posted-within').value;
  form.matchMode = document.querySelector('input[name="matchMode"]:checked')?.value || 'any';
  form.hideInternships = $('hide-internships').checked;
  form.hideSeen = $('hide-seen').checked;
  const max = parseInt($('max-results').value, 10);
  form.maxResults = Number.isFinite(max) ? Math.min(Math.max(max, 1), MAX_RESULTS_LIMIT) : DEFAULT_FORM.maxResults;
}

const saveForm = () => chrome.storage.local.set({ form });

function onFormEdit(event) {
  if (event.target.id === 'skill-input') return;
  readForm();
  saveForm();
}

async function saveSettings() {
  const settings = {
    apiKey: $('api-key').value.trim(),
    model: $('model').value.trim() || DEFAULT_MODEL,
  };
  await chrome.storage.local.set({ settings });
  $('settings-msg').textContent = settings.apiKey ? 'Saved.' : 'Saved, but the API key is empty.';
}

// Liked or marked-applied posts, so results can hide them as soon as you like one.
let appliedPosts = {};

function renderAppliedInfo(applied) {
  appliedPosts = applied;
  renderResults(results);
  const count = Object.keys(applied).length;
  $('applied-info').textContent = `Remembered: ${count} post${count === 1 ? '' : 's'}.`;
  $('clear-applied').disabled = count === 0;
}

function renderSeenInfo(seen) {
  const count = countSeenPosts(seen);
  $('seen-info').textContent = `Seen before: ${count} post${count === 1 ? '' : 's'}.`;
  $('clear-seen').disabled = count === 0;
}

// Saved lists can't be rebuilt later, so clearing takes a second click.
async function confirmTwice(button, action) {
  const label = button.dataset.label || button.textContent;
  const reset = () => {
    delete button.dataset.confirming;
    button.textContent = label;
  };
  if (!button.dataset.confirming) {
    button.dataset.label = label;
    button.dataset.confirming = '1';
    button.textContent = 'Click again to clear';
    setTimeout(reset, 4000);
    return;
  }
  reset();
  await action();
}

// Newest first, so contacts from the latest search are at the top.
let savedContacts = [];

const contactName = contact =>
  contact.company || contact.authorName || 'Company not stated';

const allEmails = () => [...new Set(savedContacts.flatMap(contact => contact.emails))];
const allPhones = () => [...new Set(savedContacts.flatMap(contact => contact.phones))];

// One line per post: "Company | Job title | emails | phones".
const contactLines = () =>
  savedContacts.map(contact =>
    [contactName(contact), contact.jobTitle || MISSING, contact.emails.join(', ') || MISSING, contact.phones.join(', ') || MISSING].join(' | '),
  );

const plural = (count, word) => `${count} ${word}${count === 1 ? '' : 's'}`;

function renderSavedContacts(saved) {
  savedContacts = Object.values(saved).sort((a, b) => b.foundAt - a.foundAt);
  const emailCount = allEmails().length;
  const phoneCount = allPhones().length;

  $('contacts-title').textContent = `All contacts (${savedContacts.length})`;
  $('contacts-summary').textContent = savedContacts.length
    ? `${plural(emailCount, 'email')} · ${plural(phoneCount, 'phone number')} from all your searches.`
    : 'Emails and phone numbers from all your searches appear here.';
  $('copy-emails').disabled = !emailCount;
  $('copy-phones').disabled = !phoneCount;
  $('copy-contacts').disabled = !savedContacts.length;
  $('clear-contacts').disabled = !savedContacts.length;
  $('contacts-msg').textContent = '';

  $('contacts-list').replaceChildren(...savedContacts.map(renderContact));
  if (!savedContacts.length) $('contacts-list').append(el('li', 'hint', 'No contacts found yet.'));
}

function renderContact(contact) {
  const item = el('li');
  const name = [contactName(contact), contact.jobTitle].filter(Boolean).join(' — ');
  item.append(el('div', 'contact-name', name));
  if (contact.emails.length) item.append(contactLine('Email', contact.emails));
  if (contact.phones.length) item.append(contactLine('Phone', contact.phones));
  if (contact.postUrl) item.append(link('Open post', contact.postUrl));
  return item;
}

function contactLine(label, values) {
  const line = el('div', 'contact-line');
  line.append(el('span', 'hint', `${label}: `), el('span', 'contact-value', values.join(', ')));
  return line;
}

async function copyLines(lines, word) {
  try {
    await navigator.clipboard.writeText(lines.join('\n'));
    $('contacts-msg').textContent = `${plural(lines.length, word)} copied.`;
  } catch {
    $('contacts-msg').textContent = 'Could not copy. Click inside the panel and try again.';
  }
}

// Runs tools/diagnose-linkedin.js in the search tab and shows its report here.
async function runDiagnosis() {
  const { searchTabId } = await chrome.storage.session.get('searchTabId');
  const tab = searchTabId ? await chrome.tabs.get(searchTabId).catch(() => null) : null;
  if (!tab) {
    $('diagnose-msg').textContent = 'The LinkedIn search tab is closed. Run a search first.';
    return;
  }
  try {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['tools/diagnose-linkedin.js'],
    });
    $('diagnose-report').value = injection?.result || 'No report returned.';
    $('diagnose-report').hidden = false;
    $('copy-report').hidden = false;
    $('diagnose-msg').textContent = 'Copy the report and send it to fix selectors.js.';
  } catch (err) {
    $('diagnose-msg').textContent = `Could not read the LinkedIn tab: ${err.message}`;
  }
}

async function copyReport() {
  try {
    await navigator.clipboard.writeText($('diagnose-report').value);
    $('diagnose-msg').textContent = 'Report copied.';
  } catch {
    $('diagnose-report').select();
    $('diagnose-msg').textContent = 'Press Ctrl+C to copy the selected report.';
  }
}

async function onMarkApplied(job) {
  const keys = [job.urn || urnFromUrl(job.postUrl), job.textKey].filter(Boolean);
  for (const key of keys) await chrome.runtime.sendMessage({ type: 'SET_APPLIED', key, applied: true });
  await chrome.storage.local.set({ results: results.filter(other => other !== job) });
}

// Accepts one skill or a comma-separated list ("Node.js, Express, MongoDB").
function addSkillsFromInput() {
  const input = $('skill-input');
  const entries = input.value.split(',').map(normalizeSkill).filter(Boolean);
  const notes = [];
  for (const skill of entries) {
    if (form.skills.some(existing => skillKey(existing) === skillKey(skill))) {
      notes.push(`"${skill}" is already added.`);
    } else if (form.skills.length >= MAX_SKILLS) {
      notes.push(`You can add up to ${MAX_SKILLS} skills.`);
      break;
    } else {
      form.skills.push(skill);
    }
  }
  input.value = '';
  $('skill-msg').textContent = notes.join(' ');
  saveForm();
  renderSkills();
}

function removeSkill(skill) {
  form.skills = form.skills.filter(existing => existing !== skill);
  $('skill-msg').textContent = '';
  saveForm();
  renderSkills();
}

function renderSkills() {
  const list = $('skill-chips');
  list.replaceChildren(
    ...form.skills.map(skill => {
      const removeButton = el('button', 'chip-remove', '×');
      removeButton.type = 'button';
      removeButton.setAttribute('aria-label', `Remove ${skill}`);
      removeButton.addEventListener('click', () => removeSkill(skill));
      const chip = el('li', 'chip', skill);
      chip.append(removeButton);
      return chip;
    }),
  );
  if (!form.skills.length) list.append(el('li', 'hint', 'No skills yet. Add at least one.'));
}

async function onSearch(event) {
  event.preventDefault();
  if ($('skill-input').value.trim()) addSkillsFromInput();
  readForm();
  await saveForm();

  const formMsg = $('form-msg');
  if (!form.role) return void (formMsg.textContent = 'Enter a role.');
  if (!form.skills.length) return void (formMsg.textContent = 'Add at least one skill.');
  const { settings } = await chrome.storage.local.get('settings');
  if (!settings?.apiKey) {
    $('settings-panel').open = true;
    formMsg.textContent = 'Add your Gemini API key in Settings first.';
    return;
  }
  if (!(await renderAccess())) {
    formMsg.textContent = 'Click "Allow access" at the top first.';
    return;
  }
  formMsg.textContent = '';

  const response = await chrome.runtime.sendMessage({ type: 'START_SEARCH', query: { ...form } });
  if (!response?.ok) formMsg.textContent = response?.error || 'Could not start the search.';
}

// Firefox only keeps the background script alive while it receives events,
// so the panel pings it during a search. Harmless in Chrome.
const KEEP_ALIVE_MS = 10000;
let keepAliveTimer = null;

function keepBackgroundAlive(running) {
  if (running && !keepAliveTimer) {
    keepAliveTimer = setInterval(() => chrome.runtime.sendMessage({ type: 'KEEP_ALIVE' }).catch(() => {}), KEEP_ALIVE_MS);
  } else if (!running && keepAliveTimer) {
    clearInterval(keepAliveTimer);
    keepAliveTimer = null;
  }
}

// Firefox may not grant the manifest's site access at install, and asking
// for it must come from a click.
const REQUIRED_ORIGINS = chrome.runtime.getManifest().host_permissions;

async function renderAccess() {
  const granted = await chrome.permissions.contains({ origins: REQUIRED_ORIGINS }).catch(() => true);
  $('access-box').hidden = granted;
  return granted;
}

async function grantAccess() {
  await chrome.permissions.request({ origins: REQUIRED_ORIGINS }).catch(() => false);
  await renderAccess();
}

function renderState(state) {
  const running = state?.status === 'running';
  keepBackgroundAlive(running);
  $('search-btn').disabled = running;
  $('cancel-btn').hidden = !running;

  if (!state?.status) {
    $('status').hidden = true;
    return;
  }
  $('status').hidden = false;
  $('status').classList.toggle('is-error', state.status === 'error');
  $('diagnose-box').hidden = !(state.status === 'error' && state.error?.code === 'DOM_NOT_FOUND');
  $('status-text').textContent = statusMessage(state);
  $('status-counts').textContent =
    `Posts scanned: ${state.scanned || 0} · Skipped (applied or seen before): ${state.skippedApplied || 0} · ` +
    `Mention your skills: ${state.prefiltered || 0} · ` +
    `Checked: ${state.analyzed || 0}${state.basicChecked ? ` (${state.basicChecked} with basic matching)` : ''} · ` +
    `Matched: ${state.matched || 0}${state.model ? ` · Model: ${state.model}` : ''}`;
}

function statusMessage(state) {
  switch (state.status) {
    case 'running':
      return `${state.step || 'Searching…'} Keep the LinkedIn tab open.`;
    case 'done':
      if (state.matched) {
        return state.basicChecked
          ? `Search finished. Gemini's free limit was reached, so ${state.basicChecked} posts were checked with basic ` +
              'keyword matching instead. Those results are marked, and may be less accurate or miss the company and job title.'
          : 'Search finished.';
      }
      return state.skippedApplied
        ? 'No new hiring posts found. The matching posts LinkedIn shows were already shown to you or applied. ' +
            'Try another skill, a longer "Posted within", or untick "Hide posts from earlier searches".'
        : 'No matching hiring posts found. Try fewer skills, "Any skill", or a longer date range.';
    case 'cancelled':
      return 'Search cancelled. Showing what was found so far.';
    case 'error':
      return state.error?.message || 'Something went wrong.';
    default:
      return '';
  }
}

const isApplied = job =>
  [job.urn || urnFromUrl(job.postUrl), job.textKey].some(key => key && appliedPosts[key]);

function renderResults(next) {
  results = next;
  const visible = results.filter(job => !isApplied(job));
  $('results-section').hidden = !visible.length;
  $('results-title').textContent = `${visible.length} job post${visible.length === 1 ? '' : 's'}`;
  $('results').replaceChildren(...visible.map(renderResult));
}

function renderResult(job) {
  const item = el('li', 'card result');

  const title = el('h3', 'result-title', job.jobTitle || 'Job title not stated');
  const company = el('p', 'result-company', job.company || 'Company not stated');
  if (job.checkedBy === 'basic') {
    company.append(el('span', 'hint', ' · Checked without Gemini (basic matching)'));
  }

  const skills = el('ul', 'chips');
  skills.setAttribute('aria-label', 'Matched skills');
  skills.append(...job.matchedSkills.map(skill => el('li', 'chip chip-match', skill)));

  const details = el('dl', 'result-details');
  addDetail(details, 'Location', job.location);
  addDetail(details, 'Mode', job.workMode);
  addDetail(details, 'Experience', job.experience);
  addDetail(details, 'Email', job.emails.join(', '));
  addDetail(details, 'Phone', job.phones.join(', '));
  addDetail(details, 'Posted by', [job.authorName, job.postDate].filter(Boolean).join(' · '));

  const links = el('div', 'actions');
  if (job.postUrl) links.append(link('Open post', job.postUrl));
  if (job.applyLink) links.append(link('Apply link', job.applyLink));
  const appliedButton = el('button', '', 'Mark applied');
  appliedButton.type = 'button';
  appliedButton.title = 'Hide this post now and in future searches';
  appliedButton.addEventListener('click', () => onMarkApplied(job));
  links.append(appliedButton);

  item.append(title, company, skills, details, links);
  return item;
}

function addDetail(list, label, value) {
  list.append(el('dt', '', label), el('dd', '', value || MISSING));
}

function link(text, href) {
  const anchor = el('a', 'button-link', text);
  anchor.href = href;
  anchor.target = '_blank';
  anchor.rel = 'noopener noreferrer';
  return anchor;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

const exportableResults = () => results.map(({ order, ...job }) => job);

function exportCsv() {
  const csv = toCsv(exportableResults(), CSV_COLUMNS);
  // The BOM makes Excel read the file as UTF-8.
  const blob = new Blob(['﻿', csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `linkedin-jobs-${new Date().toISOString().slice(0, 10)}.csv`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function copyJson() {
  try {
    await navigator.clipboard.writeText(JSON.stringify(exportableResults(), null, 2));
    $('export-msg').textContent = 'JSON copied.';
  } catch {
    $('export-msg').textContent = 'Could not copy. Click inside the panel and try again.';
  }
}
