// Shared like detection, loaded before content.js and like-watcher.js.
// A liked post means "already applied", so it never shows in results.
globalThis.LJF_LIKES = (() => {
  const SEL = globalThis.LJF_SELECTORS;
  const URN_RE = /urn:li:(?:activity|ugcPost|share):\d+/;
  const REACTION_NAMES = /^(?:like|celebrate|support|love|insightful|funny|curious)$/i;

  const labelOf = button => button.getAttribute('aria-label') || '';
  const visibleText = button => (button.innerText || '').trim();

  const inComment = button => Boolean(button.closest(SEL.comment.join(',')));

  // The main Like/React button under a post, not a comment's Like, the
  // reactions count, or the reactions menu.
  const isReactionTrigger = button =>
    !inComment(button) &&
    !button.closest(SEL.reactionMenu.join(',')) &&
    (button.matches(SEL.reactionTrigger.join(',')) ||
      /^(?:react|unreact|like)\b|reaction button state/i.test(labelOf(button)) ||
      REACTION_NAMES.test(visibleText(button)));

  // One of the reaction choices in the pop-up menu (Celebrate, Love, ...).
  const isReactionMenuChoice = button =>
    !inComment(button) &&
    Boolean(button.closest(SEL.reactionMenu.join(','))) &&
    REACTION_NAMES.test(labelOf(button) || visibleText(button));

  const isLikedButton = button =>
    button.matches(SEL.likedButton.join(',')) ||
    SEL.likedLabelPattern.test(labelOf(button)) ||
    (button.getAttribute('aria-pressed') === 'true' && isReactionTrigger(button));

  const isLikedPost = el =>
    [...el.querySelectorAll('button')].some(button => isReactionTrigger(button) && isLikedButton(button));

  // Comment URNs embed the post URN; skip them so a reply's id isn't used.
  const urnInAttributes = el => {
    for (const attr of el.attributes) {
      if (attr.value.includes('urn:li:comment')) continue;
      const urn = attr.value.match(URN_RE)?.[0];
      if (urn) return urn;
    }
    return null;
  };

  // The post a button belongs to, keyed the same way content.js keys posts:
  // the post URN, else "link:<post url>" from the card's own post link.
  const postKeyFor = button => {
    for (let el = button; el && el !== document.body; el = el.parentElement) {
      const urn = urnInAttributes(el);
      if (urn) return urn;
    }
    const card = button.closest(SEL.listItemCard.join(','));
    const link = card && card.querySelector(SEL.postLink.join(','));
    if (!link) return null;
    const url = link.href.split('?')[0];
    return url.match(URN_RE)?.[0] || `link:${url}`;
  };

  return { isReactionTrigger, isReactionMenuChoice, isLikedButton, isLikedPost, postKeyFor };
})();
