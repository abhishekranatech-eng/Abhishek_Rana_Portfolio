# LinkedIn Hiring Post Finder

A Chrome extension that finds LinkedIn **posts** in which people or recruiters are hiring for your role and skills. It uses Google Gemini's free tier to skip posts that aren't hiring and to pull out the job details.

## What it does

1. You enter a role (for example "Backend Developer") and add your skills one at a time (for example Node.js, Express, MongoDB). Your skills are saved for next time.
2. You choose whether a post must need **any** of your skills or **all** of them.
3. The extension opens LinkedIn's post search in a tab, sorted newest first, and scrolls slowly to read the posts.
4. Each post goes through three checks:
   - **LinkedIn search:** "hiring" + role + your first 2 skills + location.
   - **Local check:** the post text must mention at least one of your skills as a whole word. This also catches spellings like "nodejs" and "node js".
   - **Gemini check:** the post must be a real job opening for your role, and its required skills must fit your Any/All choice.
5. You get up to 20 results (you can set up to 50). Each one shows the company, job title, matched skills, location, work mode, experience, email, phone, who posted it, and a link to the post.
6. You can export the results as CSV or copy them as JSON.

### Already-applied posts are hidden

- Any post you have **liked** (or reacted to) on LinkedIn counts as "already applied". The extension skips it and remembers it.
- Liking a post anywhere on LinkedIn (feed, search, a post page) saves it as applied straight away, and it disappears from the results panel. Unliking it removes it from the list again. Liking a comment doesn't count.
- LinkedIn pages that were already open when you installed or reloaded the extension need a refresh before likes there are noticed.
- Each result has a **Mark applied** button for jobs you applied to without liking the post. The post disappears now and in future searches.
- Skipped posts don't count toward your 20 results. The extension scrolls further to fill the list.
- **Settings** shows how many posts are remembered. **Clear applied list** forgets them all; click it twice to confirm.

### Each search brings new posts

- Every post a search shows you goes on a "seen before" list, with its emails, phone numbers and company + job title. Later searches skip those, including reposts of the same job with the same contact details.
- Each search uses a different search phrase ("hiring", "we are hiring", "looking for", "job opening", "urgent hiring", "immediate joiner"), and a different pair of your skills when you have more than two. LinkedIn then returns a different set of posts each time.
- If one phrase runs out before Max results, the search tries up to 3 phrases in the same run.
- Untick **Hide posts from earlier searches** to see old posts again. **Settings → Clear seen list** forgets them all (click twice).

### All contacts

The extension clicks each post's **…more** button before reading it, so emails and phone numbers further down a long post are found too.

The **All contacts** section in the panel keeps one row per job post that had an email or a phone number, across all your searches, newest first. Each row shows the company, job title, emails, phones, and a link to the post.

- **Copy emails** copies every unique email, one per line.
- **Copy phones** copies every unique phone number, one per line.
- **Copy all** copies one line per post: `Company | Job title | emails | phones`.
- **Clear** empties the list; click it twice to confirm.

Email and phone are shown only when the poster wrote them in the post. Anything Gemini returns is checked against the post text, so contact details are never invented. A missing value is shown as `-`.

## Setup

1. Get a free Gemini API key at <https://aistudio.google.com/apikey>.
2. In Chrome, open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and select this `linkedin-job-finder` folder.
4. Log into LinkedIn in the same Chrome profile.
5. Click the extension icon. A side panel opens.
6. Open **Settings**, paste your API key, and click **Save settings**.

Requires Chrome 121 or newer.

### Firefox

The same folder works in Firefox 128 or newer. Firefox opens it in its sidebar.

**Quick try (removed when Firefox restarts):**

1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on…** and select `manifest.json` in this folder.
3. Click the extension's toolbar button, or use **View → Sidebar → Hiring Post Finder**.
4. If the sidebar shows **Allow access**, click it and accept. Firefox may not grant access to LinkedIn and Gemini automatically.
5. Open **Settings**, paste your API key, and click **Save settings**.

**Keep it installed:** regular Firefox only installs extensions signed by Mozilla. Either:

- **Sign it yourself (free):** create API keys at <https://addons.mozilla.org/developers/addon/api/key/>, then run:
  `npx web-ext sign --channel=unlisted --api-key=<JWT issuer> --api-secret=<JWT secret>`
  in this folder. Install the `.xpi` it creates by dragging it into Firefox. "Unlisted" means it isn't published on the add-ons store.
- **Or use Firefox Developer Edition or Nightly:** set `xpinstall.signatures.required` to `false` in `about:config`, then install the zip from `../linkedin-job-finder-dist/`.

## Using it

1. Fill in Role, add your skills, and set the optional filters.
2. Click **Search**. A LinkedIn tab opens. Keep it open until the search finishes. The side panel shows live progress.
3. Click **Cancel** at any time to keep what has been found so far.

## Settings

- **Gemini model:** defaults to `gemini-2.5-flash`. If Google retires that model, the panel shows "model not found". Change the name to a current free-tier Flash model from <https://ai.google.dev/gemini-api/docs/models>.

## Files

| File | Purpose |
| --- | --- |
| `manifest.json` | Extension config (Manifest V3) |
| `background.js` | Runs the search: opens the tab, filters posts, calls Gemini, saves results |
| `content.js` | Runs inside the LinkedIn tab, reads and scrolls the visible posts |
| `selectors.js` | All LinkedIn page selectors, in one place |
| `sidepanel.html/js/css` | The panel: form, skills, progress, results, export |
| `utils/gemini.js` | Gemini API call, JSON schema, retries |
| `utils/skills.js` | Skill spellings and whole-word matching |
| `utils/contacts.js` | Email and phone extraction and checks |
| `utils/csv.js` | CSV export |

## When it breaks

LinkedIn changes its page markup often. If the class names stop working, the extension falls back to finding posts by their LinkedIn post ID (`urn:li:activity:…`) in any attribute.

If the panel still says *"Could not find posts on the LinkedIn page"*, a **Diagnose LinkedIn page** button appears under the error. Make sure posts are visible in the LinkedIn search tab, click it, then click **Copy report**.

To run the same report by hand instead:

1. Open the LinkedIn search results tab the extension opened, and wait until posts are visible.
2. Press F12 and open the **Console** tab. If Chrome blocks pasting, type `allow pasting` and press Enter.
3. Paste the whole of `tools/diagnose-linkedin.js` and press Enter. A short report of the page structure is copied to your clipboard. It contains no post text or names.
4. Use the report to update the lists in `selectors.js`, then reload the extension at `chrome://extensions`.

## When Gemini's free limit runs out

Google's free tier allows only a small number of requests per model per day, and a few per minute.

- **Per-minute limit:** the extension waits and retries, then moves to another Flash model for the rest of the search.
- **Per-day limit:** it moves straight to the next Flash model your key can use (e.g. `gemini-flash-lite-latest`). It remembers the used-up model until the quota resets at midnight Pacific time, so later searches skip it.
- **Every model used up:** the rest of the search uses basic keyword matching. Those results say "Checked without Gemini". They may be less accurate, and the company and job title will show as "not stated". Emails and phone numbers are still found.
- Each Gemini request checks 20 posts, so a 20-result search usually needs only 1–3 requests.

## Limits and risks

- **LinkedIn's terms ban scraping and automation.** This extension only runs when you click Search, reads only the page in your own logged-in tab, scrolls at a human pace, and never visits profiles. Even so, LinkedIn could restrict your account. Use it in moderation.
- **Gemini free tier:** it has per-minute and per-day request limits. One search makes about 1 to 6 requests. If you hit the limit, wait a minute. On the free tier, Google may use the data you send to improve its products. Only post text is sent; your LinkedIn session is never sent.
- **Personal data:** emails and phone numbers belong to real people. Use them only to apply for jobs, and follow data-protection laws (for example India's DPDP Act and the EU's GDPR).
